//Pintar la calificacionn de likes en la paguina
$('#btn-like').click(function(e){
    e.preventDefault();
    let imgId = $(this).data('id');
    console.log(imgId)
    $.post('/publication/' + imgId + '/like')
      .done(data => {
      console.log(data);
        $('.likes-count').text(data.calificacionLikes);
      });

});

$('#btn-delete').click(function(e){
    e.preventDefault();
    let $this = $(this);
    const respuesta = confirm('¿Seguro que desea eliminar la publicación?')
    if(respuesta){
        let imgId = $this.data('id');
        $.ajax({
            url: '/publication/' + imgId,
            type: 'DELETE'
        })
        .done(function (result) {
          $this.removeClass('btn-danger').addClass('btn-success');
          $this.find('i').removeClass('fa-times').addClass('fa-check');
          $this.append('<span>Borrado!</span>');
        });
    }

});
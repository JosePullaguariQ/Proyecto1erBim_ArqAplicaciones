const path = require('path');
const { engine } = require('express-handlebars');
const exphbs = require('express-handlebars');

const morgan = require('morgan');
const multer = require('multer');
const express = require('express');
const errorHandler = require('errorhandler');

const routes = require('../routes/index');




// Configuracion express
module.exports = app =>  {

    // Puerto del sistema o el 3000
    app.set('port', process.env.PORT || 3000);
    app.set('views', path.join(__dirname, '../views')) // Concatenación del nombre de la carpeta
    app.engine('.hbs', engine({                    // Utilizacion de handlebars
        defaultLayout: 'main',
        partialsDir: path.join(app.get('views'), 'partials'), // Establecer partials y layouts que pertenecen dentro de views
        layoutsDir: path.join(app.get('views'), 'layouts'),
        extname: '.hbs',
        helpers: require('./helpers')
    }));

    // Empezar a utilizar el handlebars con motor de plantillas .hbs
    app.set('view engine', '.hbs'); 

    // Agregación de otros módulos
    // Middlewares
    app.use(morgan('dev'));
    app.use(multer({dest: path.join(__dirname, '../public/upload/temp')}).single('publicacion')); // Almacenar 1 sola imagen con multer
    app.use(express.urlencoded({extended: false})) // Recibir datos q vienen de formularios
    app.use(express.json());                       // Ajax para likes

    // Rutas
    routes(app);

    // Carpetas estáticas
    app.use('/public', express.static(path.join(__dirname, '../public'))); 

    // Manejador de errores (errorhanlers)
    if ('development' == app.get('env')){
        app.use(errorHandler);
    }

    return app;
}
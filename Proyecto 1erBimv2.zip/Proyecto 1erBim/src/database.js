// Conexión base de datos

const mongoose = require('mongoose');

// Importacion de keys database
const { database } = require('./keys')

// Direccion de mongo db
mongoose.connect(database.URI, {
    useNewUrlParser: true // Mongoose
})
    .then(db => console.log('Base de datos conectada'))
    .catch(err => console.log(err));
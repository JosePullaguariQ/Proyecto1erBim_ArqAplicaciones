const mongoose = require('mongoose');

const mongooseLeanVirtuals = require('mongoose-lean-virtuals');

const {Schema, model} = mongoose;
const path = require('path');

const PublicacionSchema = new Schema({
    titulo: { type: String },
    descripcion: {type: String },
    fichero: { type: String },
    vistas: { type: Number, default: 0},
    calificacionLikes: { type: Number, default: 0},
    fecha: { type: Date, default: Date.now }

});

// nueva linea
PublicacionSchema.plugin(mongooseLeanVirtuals);

// variable virtual para obtener nombre sin extension
PublicacionSchema.virtual('identificadorId')
    .get(function(){
        return this.fichero.replace(path.extname(this.fichero), '')
    });

// Convertimos en modelo
module.exports = mongoose.model('publicacion', PublicacionSchema)
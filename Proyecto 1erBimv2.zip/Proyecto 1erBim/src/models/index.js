module.exports = {
    Publicacion: require('./publicacion'),
    Comment: require('./comentario')
    
};

const ctrl = {}; // Creamos un objeto

const { Publicacion } = require('../models');

// Creamos la funcion de nuestro objeto
ctrl.index = async (req, res, next) =>{  
    try{
        const publicaciones = await Publicacion.find().sort({fecha: -1}).lean({ virtuals: true });  // Busqueda en la bd ordenado 
        let vistaModelo = { publicaciones: [] };
        vistaModelo.publicaciones = publicaciones;
        //vistaModelo = await sidebar(vistaModelo);

        res.render('index', vistaModelo);  // Pinta por pantalla lo q obtenemos 
    } 
    catch(error){
        next(error);
    }   
       
};


module.exports = ctrl;                  // Exportamos nuestro objeto
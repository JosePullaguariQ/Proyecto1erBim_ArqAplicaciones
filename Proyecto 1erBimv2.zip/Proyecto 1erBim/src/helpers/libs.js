// Funciones complementarias

const helpers = {}

helpers.randomNombre = () => {
     const caracteresPosibles = 'abcdefghijklmnopqrstuvwxyz0123456789';
     let numeroAleatorio = 0;   // cambia el valor
     for(let i = 0; i < 6; i++){
         numeroAleatorio += caracteresPosibles.charAt(Math.floor(Math.random() * caracteresPosibles.length)); // Redondeo y longitud
     }

     return numeroAleatorio;
}

module.exports =  helpers;
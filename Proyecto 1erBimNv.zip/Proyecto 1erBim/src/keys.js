module.exports = {
    // Propiedad 
    database:  {
        URI: 'mongodb://localhost/dbredsocial'
    }
}
const express =  require('express');
const router = express.Router();

const home = require('../controllers/home');
const image = require('../controllers/image');

// RUTAS  

module.exports = app => {

    router.get('/', home.index);
    router.get('/publication/:publi_id', image.index);
    router.post('/publication', image.createPublic);
    router.post('/publication/:publi_id/like', image.likePublic);
    router.post('/publication/:publi_id/comment', image.commentPublic);
    router.delete('/publication/:publi_id', image.deletePublic);

    app.use(router);

};

// Configuracion del servidor 

const express =  require('express');

const config  = require('../src/server/config');

require('./database'); // Ejecuta lo de database

const app = config(express());

// Inicializando el servidor
app.listen(app.get('port'), () => {
    console.log('Puerto del servidor', app.get('port'));
});
const moment = require('moment');
const helpers = {};
//Tranformar el formato del tiempo
helpers.tiempoTra = timestamp => {
    return moment(timestamp).startOf('minute').fromNow(); 
}

module.exports = helpers; 
const path = require('path');
const {randomNombre} = require('../helpers/libs')

// Modulo file system 
const fs = require('fs-extra');
const md5 = require('md5');

const { Publicacion,Comment }  = require('../models');
const comentario = require('../models/comentario');

const ctrl = {}; // Creamos un objeto

// Creamos la funcion de nuestro objeto
ctrl.index = async (req, res, next) =>{

    let vistaModelo = { publicacion: {},comentario: {}};

    
    const publicacion = await Publicacion.findOne({fichero: { $regex: req.params.publi_id }}).lean({ virtuals: true }); // Busca una sola publicacion
    vistaModelo.publicacion = publicacion;
 
    if (!publicacion) return next(new Error("La imagen no existe"));

    //Listamos los comentarios
    const comentarios = await Comment.find({image_id: publicacion._id }).sort({
        timestamp: 1,
      }).lean({ virtuals: true });
      vistaModelo.comentario = comentarios;
     
      //Contar el numero de visitas

      const publicacion2 = await Publicacion.findOne({fichero: {$regex: req.params.publi_id}});
      if(publicacion2){
          publicacion2.vistas = publicacion2.vistas + 1;
          await publicacion2.save();
          console.log(publicacion2.vistas);
          
      }

      console.log(vistaModelo);
      res.render("image", vistaModelo);
    
    
    
    
   
};

// Creamos publicacion
ctrl.createPublic = (req, res) =>{
    
    const guardarPublicacion = async () =>{
        const nameImage = randomNombre();
        const publicaciones = await Publicacion.find({filename: nameImage}); // Buscamos en la bd

        // Validacion de nombre aleatorio
        if( publicaciones > 0 ){
            guardarPublicacion();
        }
        else
        {

            console.log(nameImage); 
            const direccionP = req.file.path;
            const ext = path.extname(req.file.originalname).toLocaleLowerCase(); // para obtener el .png en minuscula
            const rutaNuevaP = path.resolve(`src/public/upload/${nameImage}${ext}`);

            if(ext == '.png' || ext == '.jpg' || ext == '.jpeg' || ext == '.gif'){
                await fs.rename(direccionP, rutaNuevaP); // Mover a otro directorio
                const newPublicacion = new Publicacion({
                titulo: req.body.titulo,
                fichero: nameImage + ext,
                descripcion: req.body.descripcion

                }); 
                const publicacionGuardada = await newPublicacion.save(); // Devolvemos el objeto creado
                res.redirect('/publication/' + nameImage);
                console.log(newPublicacion)
            }
            else
            {
                await fs.unlink(direccionP);
                res.status(500).json({error: 'Formato inválido para publicaciones'});
            }

            //console.log(req.file); // CARACTIERISTICAS DE LA IMAGEN
            

        }       
    };

    guardarPublicacion();

    

    
};
//Contar los likes de la publicación 
ctrl.likePublic = async(req, res) =>{
    
    const publicacion1 = await Publicacion.findOne({fichero: {$regex: req.params.publi_id}});
    if(publicacion1){
        publicacion1.calificacionLikes = publicacion1.calificacionLikes + 1;
        await publicacion1.save();
        console.log(publicacion1.calificacionLikes);
        res.json({calificacionLikes: publicacion1.calificacionLikes});
    }else {
    res.status(500).json({ error: "Erros interno" });
    }
};

//Crear comentario
ctrl.commentPublic = async(req, res) =>{
    const publicacion = await Publicacion.findOne({fichero: {$regex: req.params.publi_id}});
    if (publicacion){
        const nuevoComentario = new Comment(req.body);
        nuevoComentario.gravatar = md5(nuevoComentario.email);
        nuevoComentario.image_id = publicacion._id;
        
        console.log(nuevoComentario);
        await nuevoComentario.save();
        res.redirect('/publication/'+ publicacion.identificadorId);
    
    }
};

ctrl.deletePublic = async(req, res) =>{
    const borrarPublicacion = await Publicacion.findOne({fichero: {$regex: req.params.publi_id}});
    if (borrarPublicacion){
        await fs.unlink(path.resolve(`src/public/upload/`+ borrarPublicacion.fichero));
        await Comment.deleteOne({image_id: borrarPublicacion._id});
        await borrarPublicacion.remove();
        res.json(true);

    }
};


module.exports = ctrl;                  // Exportamos nuestro objeto